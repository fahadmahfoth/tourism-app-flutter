class Url {
  static const String url = "https://tourismnineveh.codeforiraq.org";
}
